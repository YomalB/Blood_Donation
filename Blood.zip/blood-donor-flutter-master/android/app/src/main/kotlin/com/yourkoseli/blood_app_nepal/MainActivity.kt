package com.yourkoseli.blood_app_nepal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
